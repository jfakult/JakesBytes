doDelayedOnload()
